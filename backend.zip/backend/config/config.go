package config

// EffortType is one of your named dimensions (Analysis, Development, Testing)
type EffortType struct {
	Title      string `json:"title"`
	OrderIndex int    `json:"orderIndex,omitempty"`
}

// ColumnConfig may have nested sub-columns
type ColumnConfig struct {
	Title      string         `json:"title"`
	OrderIndex int            `json:"orderIndex"`
	WIPLimit   int            `json:"wipLimit,omitempty"`
	Subcolumns []ColumnConfig `json:"subcolumns,omitempty"`
}

// InitialCardConfig represents each card you seed at game-creation
type InitialCardConfig struct {
	Title          string     `json:"title"`
	ClassOfService string     `json:"classOfService"`
	ColumnTitle    string     `json:"columnTitle,omitempty"` // if you switched to titles
	ColumnID       string     `json:"columnId,omitempty"`    // or if you’re still using IDs
	ValueEstimate  string     `json:"valueEstimate"`
	Efforts        []struct { // dynamic list of efforts
		EffortType string `json:"effortType"`
		Estimate   int    `json:"estimate"`
	} `json:"efforts"`
	SelectedDay int  `json:"selectedDay,omitempty"`
	DeployedDay *int `json:"deployedDay,omitempty"`
}

// BoardConfig is the top-level struct matching your JSON
type BoardConfig struct {
	EffortTypes  []EffortType        `json:"effortTypes"`
	Columns      []ColumnConfig      `json:"columns"`
	InitialCards []InitialCardConfig `json:"initialCards"`
}
